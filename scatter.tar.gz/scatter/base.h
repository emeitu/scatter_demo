#ifndef __BASE_H
#define __BASE_H
/*
Desc:基本数据类型定义
*/

#include <vector>
#include <iostream>
#include <algorithm>
#include <string>

//using namespace std;
using std::string;

struct RecItem  {
    int ID; //物料id
    string Typ; //物料类型
    int Score;  //分数
};

typedef std::vector<RecItem> RecList;


#endif
