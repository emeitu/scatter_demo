#ifndef __SCATTER_H
#define __SCATTER_H

/*
Desc: 大散，每连续10个，最多不能出3个同类属性的物料

 */

#include <iostream>
#include <vector>

#include "base.h"

class Scatter {
public:
    Scatter(int scope, int maxLimit);
    //int RunScatter(std::vector<RecItem> &recList, bool (*IsOk)(std::vector<RecItem> &recList, int idx) );
    //virtual bool IsOk(vector<RecItem> &recList, int idx, int &scope) (int, bool) = 0;
    bool IsOk(std::vector<RecItem> &recList, int idx) ;
    int RunScatter(std::vector<RecItem> &recList);
//protect:
private:
    int _scope;
    int _maxLimit;
};


#endif
