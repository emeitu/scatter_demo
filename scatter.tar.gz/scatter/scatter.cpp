#include <map>
#include <iostream>

#include "scatter.h"


using namespace std;

extern void swap(vector<RecItem> &recList, int fIdx, int sIdx );

Scatter::Scatter(int scope, int maxLimit)
{
    this->_scope = scope;
    this->_maxLimit  = maxLimit;
}

int Scatter::RunScatter(vector<RecItem> &recList) 
{
    int ret = 0;

    int size = recList.size();
    bool isOk = false;
    int changeIdx;

    //int i ;
    for (int idx=0;idx<size; idx++) {
       isOk = this->IsOk(recList, idx) ;
       if (isOk) {
            continue;
       }

       if ( idx < this->_scope ) {
            changeIdx = idx + 1;
       } else {
            changeIdx = idx + this->_scope;
       }
       for (; changeIdx < size; changeIdx++ ) {
            //需要交换位置满足条件，遍历查找
            swap(recList, idx, changeIdx);
            isOk = this->IsOk(recList, idx);
            if (isOk) {
                break;
            } else {
                //如果失败，交换回来
                swap(recList, idx, changeIdx);
            }
       }
       isOk =  this->IsOk(recList, idx);
       if ( !isOk ) {
            ret = 1;
            //交换完后仍不满足，打散结束
            break;
       }
    }    

    return ret;
}

bool Scatter::IsOk(vector<RecItem> &recList, int idx)
{
    int startIdx = idx - _scope + 1;
    if (startIdx < 0) {
        startIdx = 0;
    }

    int size = recList.size();
    map<string,int> m;
    int count;
    for (int i=startIdx; (i<=idx) && (i<size); i++) {
       count = m[ recList[i].Typ  ] + 1;
       if (count > _maxLimit) {
            return false;
       }

       m[ recList[i].Typ  ] = count;
    }

    return true;
}


void swap(vector<RecItem> &recList, int fIdx, int sIdx )
{
    RecItem tmpItem;
    tmpItem = recList[fIdx]; 
    recList[fIdx] = recList[sIdx];
    recList[sIdx] = tmpItem;
}
