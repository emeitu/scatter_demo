/*
 Desc:产生100个数据
 */
#include <iostream>  
#include <vector>  
#include <algorithm>  
#include <sstream>
  
#include "base.h"
#include "generate_data.h"

using namespace std;

void GenerateVector(vector<RecItem> &recList, int num)
{
    RecItem item;

    for(; num>0; num--) {
        item.ID = num;
        item.Typ = Int2String( num );
        item.Score = num;

        if ( (num>80) && (num<90) ) {
            item.Typ = Int2String(99);
            item.Score = 99;
        }

        recList.push_back(item);
    }

}

string Int2String(int num)
{
	stringstream sstr;
    sstr << num;

    string str;
    sstr >> str;

    return str;
}
