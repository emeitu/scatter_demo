#ifndef __GENERATE_DATA_H
#define __GENERATE_DATA_H

#include <iostream>

void GenerateVector(std::vector<RecItem> &recList, int num=100);
string Int2String(int num) ;

#endif
