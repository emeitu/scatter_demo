# include <stdio.h>
# include <stdlib.h>

#include <iostream>  
#include <vector>  
#include <algorithm>  
  
#include "base.h"
#include "generate_data.h"
#include "scatter.h"

using namespace std;


bool GreaterSort (RecItem f, RecItem s);
void printVector(vector<RecItem> &recList, int intervalNum=10);

int main(int argc, char ** argv) {
   vector<RecItem> recList ;
   int maxNum  = 100;
   GenerateVector(recList, maxNum);

   cout<<"size:" << recList.size()<<endl;
   //排序从高到低
   sort(recList.begin(), recList.end(), GreaterSort);
   printVector(recList);

   cout<<"-------------start scatter---------------"<<endl<<endl;


   int scope = 10;
   int maxLimit = 2;
   //连续的10个item里最多能出2个相同Type的item
   //Scatter scatter = new Scatter(scope, maxLimit);
   Scatter scatter(scope, maxLimit);
   int ret = scatter.RunScatter(recList);

   printVector(recList);
   cout<<"ret:"<<ret<<endl;

    return 0;
}

void printVector(vector<RecItem> &recList, int intervalNum) 
{
   vector<RecItem>::iterator it = recList.begin();
   int i=1;
   for (;it!=recList.end(); it++, i++) {
        cout<< "ID:" << it->ID << " Typ:" << it->Typ << " Score:" << it->Score<<endl;
        if (i % intervalNum == 0)  {
            cout<<endl;
            cout<<endl;
        }
   }
    
}

bool GreaterSort (RecItem f, RecItem s) 
{ 
    return (f.Score > s.Score); 
}  

